/*
g++ -Wall -o ProyectoV2 ProyectoV2.cpp `pkg-config --cflags --libs opencv`

*/

#include<iostream>

#include<opencv2/core/core.hpp>
#include<opencv2/ml/ml.hpp>
#include<opencv/cv.h>
#include<opencv2/imgproc/imgproc.hpp>
#include<opencv2/highgui/highgui.hpp>

#include <stdio.h>    
#include <stdlib.h> 
#include <stdint.h>   
#include <string.h>   
#include <unistd.h>   
#include <fcntl.h>   
#include <errno.h>    
#include <termios.h>  
#include <sys/ioctl.h>
#include <getopt.h>

using namespace std;
using namespace cv;



const int train_samples = 1;
const int classes = 26;
const int sizex = 30;
const int sizey = 30;
const int ImageSize = sizex * sizey;
char pathToImages[] = "Letras";

int  A_min, A_max, B_min, B_max, C_min, C_max;


void PreProcessImage(Mat *inImage,Mat *outImage,int sizex, int sizey);
void LearnFromImages(CvMat* trainData, CvMat* trainClasses);

Mat Plantilla,Camara;
Mat Letra = imread("Letra.png",CV_LOAD_IMAGE_COLOR);
Mat Nombre = imread("Nombre.png",CV_LOAD_IMAGE_COLOR);




int main(void)
{

     namedWindow("Barras");
     createTrackbar("A-min ", "Barras", &A_min, 255, NULL);
     createTrackbar("A-max ", "Barras", &A_max, 255, NULL);
     createTrackbar("B-min ", "Barras", &B_min, 255, NULL);
     createTrackbar("B-max ", "Barras", &B_max, 255, NULL);
     createTrackbar("C-min ", "Barras", &C_min, 255, NULL);
     createTrackbar("C-max ", "Barras", &C_max, 255, NULL);

     Mat Camara_chica,Camara_chica2;
     Mat ImagenGray,ImagenHSV,HSVblur,color,color2,Fruta,Fruta2;
     Mat image,imagen,imagen_contornos,staged_image,imagen_file;
     
     int result=0; 
     int A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z,count=0;	
     A=B=C=D=E=F=G=H=I=J=K=L=M=N=O=P=Q=R=S=T=U=V=W=X=Y=Z=0;	

	CvMat* sample2= cvCreateMat(1, ImageSize,CV_32FC1); 
	Rect rec;

	CvMat* trainData = cvCreateMat(classes * train_samples,ImageSize, CV_32FC1);
 	CvMat* trainClasses = cvCreateMat(classes * train_samples, 1, CV_32FC1);
	
        LearnFromImages(trainData, trainClasses);
        KNearest knearest(trainData, trainClasses);
	
	vector<vector<Point> > contornos;// arreglo de arreglos 
	VideoCapture cam(0);
	if(!cam.isOpened()) return -1;

       
	Plantilla=imread("Plantilla3.png",CV_LOAD_IMAGE_COLOR);
        putText(Plantilla,"Camara 1",Point(650,400),FONT_HERSHEY_PLAIN,2,Scalar(0,0,0),1,CV_AA);
	putText(Plantilla,"Contorno",Point(670,690),FONT_HERSHEY_PLAIN,2,Scalar(0,0,0),1,CV_AA);
	putText(Plantilla,"Letra",Point(900,680),FONT_HERSHEY_PLAIN,2,Scalar(0,0,0),1,CV_AA);
	Rect roi2(Point(600,0),Size(400,350));
	Rect roi3(Point(650,450),Size(200,200));
	Rect roi4(Point(900,600),Size(50,50));
	Rect Roi5(Point(0,0),Size(400,350));
	Rect roi6(Point(0,400),Size(400,50));
	
	
 	for(;;)
	{
		
		

		cam >> image;
			
		cvtColor(image,ImagenHSV,CV_RGB2HSV); 
		GaussianBlur(ImagenHSV,HSVblur,Size(45,45),2,2); 	
		inRange(HSVblur,Scalar(17,125,83),Scalar(80,255,196),color); 
		//inRange(HSVblur,Scalar(A_min, B_min, C_min), Scalar(A_max, B_max, C_max),color);
		imshow("Color",color);	
		adaptiveThreshold(color,color2,255,1,1,11,2); 
		imagen_contornos=color2; 
		imwrite("contorno.png",imagen_contornos); 
		imagen_file=imread("contorno.png",1); 
		findContours(imagen_contornos,contornos,RETR_LIST,CHAIN_APPROX_SIMPLE);
		
		for (size_t i=0; i<contornos.size();i++) //se inicia ciclo for para instruccion de contornos 
		{ 
		vector < Point > cnt =contornos [i]; //guarda la posicion de contornos en la iteracion de contornos 
		if(contourArea(cnt) > 50) //Calcula el area de cada contorno superior a los 100 pixeles 
		{ 
		rec = boundingRect(cnt); //se rodea con un rectangulo a los contornos encontrados 
		if(rec.height > 50) 
 
		{ 
 
		Mat roi = imagen_file(rec); 
		Mat stagedImage; 
 		PreProcessImage(&roi, &stagedImage, sizex, sizey);
		for (int n = 0; n < ImageSize; n++) 
 		{ 
 		sample2->data.fl[n] = stagedImage.data[n]; 
 		} 
 
		result = knearest.find_nearest(sample2, 1);
		
		count++; 
		if(result==0) 
		A++; 
		if(result==1) 
		B++; 
		if(result==2) 
		C++; 
		if(result==3) 
		D++; 
		if(result==4) 
		E++; 
		if(result==5) 
		F++; 
		if(result==6) 
		G++; 
		if(result==7) 
		H++; 
		if(result==8) 
		I++; 
		if(result==9) 
		J++;
		if(result==10) 
		K++; 
		if(result==11) 
		L++; 
		if(result==12) 
		M++; 
		if(result==13) 
		N++; 
		if(result==14) 
		O++; 
		if(result==15) 
		P++; 
		if(result==16) 
		Q++; 
		if(result==17) 
		R++; 
		if(result==18) 
		S++; 
		if(result==19) 
		T++; 
		if(result==20) 
		U++; 
		if(result==21) 
		V++; 
		if(result==22) 
		W++; 
		if(result==23) 
		X++; 
		if(result==24) 
		Y++; 
		if(result==25) 
		Z++;     
		
		
		if(count==20) 
		{
 
		if(A>15){ 
		cout << " A " << "\n"; 
		Letra.copyTo(Plantilla(roi4));
		Nombre.copyTo(Plantilla(roi6));
 		putText(Plantilla," A ",Point(885,640),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
 		Fruta=imread("Frutas/Algarroba.jpg",CV_LOAD_IMAGE_COLOR);
 		resize(Fruta,Fruta2,Size(400,350),0,0,INTER_CUBIC);
 		Fruta2.copyTo(Plantilla(Roi5));
 		putText(Plantilla," Algarroba ",Point(0,440),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
		}
		if(B>15){ 
		Letra.copyTo(Plantilla(roi4));
		Nombre.copyTo(Plantilla(roi6));
		cout << " B " << "\n"; 
 		putText(Plantilla," B ",Point(885,640),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
 		Fruta=imread("Frutas/Babaco.jpg",CV_LOAD_IMAGE_COLOR);
 		resize(Fruta,Fruta2,Size(400,350),0,0,INTER_CUBIC);
 		Fruta2.copyTo(Plantilla(Roi5));
 		putText(Plantilla," Babaco ",Point(0,440),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
		}
		if(C>15){ 
 		Letra.copyTo(Plantilla(roi4));
 		Nombre.copyTo(Plantilla(roi6));
		cout << " C " << "\n"; 
 		putText(Plantilla," C ",Point(885,640),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
 		Fruta=imread("Frutas/Curuba.jpg",CV_LOAD_IMAGE_COLOR);
 		resize(Fruta,Fruta2,Size(400,350),0,0,INTER_CUBIC);
 		Fruta2.copyTo(Plantilla(Roi5));
 		putText(Plantilla," Curuba ",Point(0,440),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
		}
		if(D>15){
		Letra.copyTo(Plantilla(roi4)); 
		Nombre.copyTo(Plantilla(roi6));
		cout << " D " << "\n"; 
 		putText(Plantilla," D ",Point(885,640),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
 		Fruta=imread("Frutas/Durion.jpg",CV_LOAD_IMAGE_COLOR);
 		resize(Fruta,Fruta2,Size(400,350),0,0,INTER_CUBIC);
 		Fruta2.copyTo(Plantilla(Roi5));
 		putText(Plantilla," Durion ",Point(0,440),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
		}
		if(E>15){ 
		Letra.copyTo(Plantilla(roi4)); 
		Nombre.copyTo(Plantilla(roi6));
		cout << " E " << "\n"; 
  		putText(Plantilla," E ",Point(885,640),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
  		Fruta=imread("Frutas/Escaramujo.jpg",CV_LOAD_IMAGE_COLOR);
 		resize(Fruta,Fruta2,Size(400,350),0,0,INTER_CUBIC);
 		Fruta2.copyTo(Plantilla(Roi5));
 		putText(Plantilla," Escaramujo ",Point(0,440),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
		}
		if(F>15){ 
		cout << " F " << "\n"; 
		Letra.copyTo(Plantilla(roi4));
		Nombre.copyTo(Plantilla(roi6));
 		putText(Plantilla," F ",Point(885,640),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
 		Fruta=imread("Frutas/Frambuesa.jpg",CV_LOAD_IMAGE_COLOR);
 		resize(Fruta,Fruta2,Size(400,350),0,0,INTER_CUBIC);
 		Fruta2.copyTo(Plantilla(Roi5));
 		putText(Plantilla," Frambuesa ",Point(0,440),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
		}
		if(G>15){ 
		Letra.copyTo(Plantilla(roi4));
		Nombre.copyTo(Plantilla(roi6));
		cout << " G " << "\n"; 
 		putText(Plantilla," G ",Point(885,640),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
 		Fruta=imread("Frutas/Gandaria.jpg",CV_LOAD_IMAGE_COLOR);
 		resize(Fruta,Fruta2,Size(400,350),0,0,INTER_CUBIC);
 		Fruta2.copyTo(Plantilla(Roi5));
 		putText(Plantilla," Gandaria ",Point(0,440),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
		}
		if(H>15){ 
 		Letra.copyTo(Plantilla(roi4));
 		Nombre.copyTo(Plantilla(roi6));
		cout << " H " << "\n"; 
 		putText(Plantilla," H ",Point(885,640),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
 		Fruta=imread("Frutas/Higo.jpg",CV_LOAD_IMAGE_COLOR);
 		resize(Fruta,Fruta2,Size(400,350),0,0,INTER_CUBIC);
 		Fruta2.copyTo(Plantilla(Roi5));
 		putText(Plantilla," Higo ",Point(0,440),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
		}
		if(I>15){
		Letra.copyTo(Plantilla(roi4)); 
		Nombre.copyTo(Plantilla(roi6));
		cout << " I " << "\n"; 
 		putText(Plantilla," I ",Point(885,640),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
 		Fruta=imread("Frutas/Icaco.jpg",CV_LOAD_IMAGE_COLOR);
 		resize(Fruta,Fruta2,Size(400,350),0,0,INTER_CUBIC);
 		Fruta2.copyTo(Plantilla(Roi5));
 		putText(Plantilla," Icaco ",Point(0,440),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
		}
		if(J>15){ 
		Letra.copyTo(Plantilla(roi4)); 
		Nombre.copyTo(Plantilla(roi6));
		cout << " J " << "\n"; 
  		putText(Plantilla," K ",Point(885,640),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
  		Fruta=imread("Frutas/Jobo.jpg",CV_LOAD_IMAGE_COLOR);
 		resize(Fruta,Fruta2,Size(400,350),0,0,INTER_CUBIC);
 		Fruta2.copyTo(Plantilla(Roi5));
 		putText(Plantilla," Jobo ",Point(0,440),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
		}
		if(K>15){ 
		cout << " K " << "\n"; 
		Letra.copyTo(Plantilla(roi4));
		Nombre.copyTo(Plantilla(roi6));
 		putText(Plantilla," K ",Point(885,640),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
 		Fruta=imread("Frutas/Kiwamo.jpg",CV_LOAD_IMAGE_COLOR);
 		resize(Fruta,Fruta2,Size(400,350),0,0,INTER_CUBIC);
 		Fruta2.copyTo(Plantilla(Roi5));
 		putText(Plantilla," Kiwamo ",Point(0,440),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
		}
		if(L>15){ 
		Letra.copyTo(Plantilla(roi4));
		Nombre.copyTo(Plantilla(roi6));
		cout << " L " << "\n"; 
 		putText(Plantilla," L ",Point(885,640),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
 		Fruta=imread("Frutas/Litchi.jpg",CV_LOAD_IMAGE_COLOR);
 		resize(Fruta,Fruta2,Size(400,350),0,0,INTER_CUBIC);
 		Fruta2.copyTo(Plantilla(Roi5));
 		putText(Plantilla," Litchi ",Point(0,440),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
		}
		if(M>15){ 
 		Letra.copyTo(Plantilla(roi4));
 		Nombre.copyTo(Plantilla(roi6));
		cout << " M " << "\n"; 
 		putText(Plantilla," M ",Point(885,640),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
 		Fruta=imread("Frutas/Maracuya.jpg",CV_LOAD_IMAGE_COLOR);
 		resize(Fruta,Fruta2,Size(400,350),0,0,INTER_CUBIC);
 		Fruta2.copyTo(Plantilla(Roi5));
 		putText(Plantilla," Maracuya ",Point(0,440),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
		}
		if(N>15){
		Letra.copyTo(Plantilla(roi4)); 
		Nombre.copyTo(Plantilla(roi6));
		cout << " N " << "\n"; 
 		putText(Plantilla," N ",Point(885,640),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
 		Fruta=imread("Frutas/Noni.jpg",CV_LOAD_IMAGE_COLOR);
 		resize(Fruta,Fruta2,Size(400,350),0,0,INTER_CUBIC);
 		Fruta2.copyTo(Plantilla(Roi5));
 		putText(Plantilla," Noni ",Point(0,440),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
		}
		if(O>15){ 
		Letra.copyTo(Plantilla(roi4)); 
		Nombre.copyTo(Plantilla(roi6));
		cout << " O " << "\n"; 
  		putText(Plantilla," O ",Point(885,640),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
  		Fruta=imread("Frutas/Oliva.jpg",CV_LOAD_IMAGE_COLOR);
 		resize(Fruta,Fruta2,Size(400,350),0,0,INTER_CUBIC);
 		Fruta2.copyTo(Plantilla(Roi5));
 		putText(Plantilla," Oliva ",Point(0,440),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
		}
		if(P>15){ 
		cout << " P " << "\n"; 
		Letra.copyTo(Plantilla(roi4));
		Nombre.copyTo(Plantilla(roi6));
 		putText(Plantilla," P ",Point(885,640),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
 		Fruta=imread("Frutas/Pitahaya.jpg",CV_LOAD_IMAGE_COLOR);
 		resize(Fruta,Fruta2,Size(400,350),0,0,INTER_CUBIC);
 		Fruta2.copyTo(Plantilla(Roi5));
 		putText(Plantilla," Pitahaya ",Point(0,440),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
		}
		if(Q>15){ 
		Letra.copyTo(Plantilla(roi4));
		Nombre.copyTo(Plantilla(roi6));
		cout << " Q " << "\n"; 
 		putText(Plantilla," Q ",Point(885,640),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
 		Fruta=imread("Frutas/Quenepa.jpg",CV_LOAD_IMAGE_COLOR);
 		resize(Fruta,Fruta2,Size(400,350),0,0,INTER_CUBIC);
 		Fruta2.copyTo(Plantilla(Roi5));
 		putText(Plantilla," Algarroba ",Point(0,440),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
		}
		if(R>15){ 
 		Letra.copyTo(Plantilla(roi4));
 		Nombre.copyTo(Plantilla(roi6));
		cout << " R " << "\n"; 
 		putText(Plantilla," R ",Point(885,640),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
 		Fruta=imread("Frutas/Rambutan.jpg",CV_LOAD_IMAGE_COLOR);
 		resize(Fruta,Fruta2,Size(400,350),0,0,INTER_CUBIC);
 		Fruta2.copyTo(Plantilla(Roi5));
 		putText(Plantilla," Rambutan ",Point(0,440),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
		}
		if(S>15){
		Letra.copyTo(Plantilla(roi4)); 
		Nombre.copyTo(Plantilla(roi6));
		cout << " S " << "\n"; 
 		putText(Plantilla," S ",Point(885,640),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
 		Fruta=imread("Frutas/Sandia.jpg",CV_LOAD_IMAGE_COLOR);
 		resize(Fruta,Fruta2,Size(400,350),0,0,INTER_CUBIC);
 		Fruta2.copyTo(Plantilla(Roi5));
 		putText(Plantilla," Sandia ",Point(0,440),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
		}
		if(T>15){ 
		Letra.copyTo(Plantilla(roi4)); 
		Nombre.copyTo(Plantilla(roi6));
		cout << " T " << "\n"; 
  		putText(Plantilla," T ",Point(885,640),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
  		Fruta=imread("Frutas/Tuna.jpg",CV_LOAD_IMAGE_COLOR);
 		resize(Fruta,Fruta2,Size(400,350),0,0,INTER_CUBIC);
 		Fruta2.copyTo(Plantilla(Roi5));
 		putText(Plantilla," Tuna ",Point(0,440),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
		}
		if(U>15){ 
		cout << " U " << "\n"; 
		Letra.copyTo(Plantilla(roi4));
		Nombre.copyTo(Plantilla(roi6));
 		putText(Plantilla," U ",Point(885,640),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
 		Fruta=imread("Frutas/Umbu.jpg",CV_LOAD_IMAGE_COLOR);
 		resize(Fruta,Fruta2,Size(400,350),0,0,INTER_CUBIC);
 		Fruta2.copyTo(Plantilla(Roi5));
 		putText(Plantilla," Umbu ",Point(0,440),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
		}
		if(V>15){ 
		Letra.copyTo(Plantilla(roi4));
		Nombre.copyTo(Plantilla(roi6));
		cout << " V " << "\n"; 
 		putText(Plantilla," V ",Point(885,640),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
 		Fruta=imread("Frutas/Vinagrillo.jpg",CV_LOAD_IMAGE_COLOR);
 		resize(Fruta,Fruta2,Size(400,350),0,0,INTER_CUBIC);
 		Fruta2.copyTo(Plantilla(Roi5));
 		putText(Plantilla," Vinagrillo ",Point(0,440),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
		}
		if(W>15){ 
 		Letra.copyTo(Plantilla(roi4));
 		Nombre.copyTo(Plantilla(roi6));
		cout << " W " << "\n"; 
 		putText(Plantilla," W ",Point(885,640),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
 		Fruta=imread("Frutas/Waba.jpg",CV_LOAD_IMAGE_COLOR);
 		resize(Fruta,Fruta2,Size(400,350),0,0,INTER_CUBIC);
 		Fruta2.copyTo(Plantilla(Roi5));
 		putText(Plantilla," Waba ",Point(0,440),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
		}
		if(X>15){
		Letra.copyTo(Plantilla(roi4)); 
		Nombre.copyTo(Plantilla(roi6));
		cout << " X " << "\n"; 
 		putText(Plantilla," X ",Point(885,640),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
 		Fruta=imread("Frutas/Xoconostle.jpg",CV_LOAD_IMAGE_COLOR);
 		resize(Fruta,Fruta2,Size(400,350),0,0,INTER_CUBIC);
 		Fruta2.copyTo(Plantilla(Roi5));
 		putText(Plantilla," Xoconostle ",Point(0,440),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
		}
		if(Y>15){ 
		Letra.copyTo(Plantilla(roi4)); 
		Nombre.copyTo(Plantilla(roi6));
		cout << " Y " << "\n"; 
  		putText(Plantilla," Y ",Point(885,640),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
  		Fruta=imread("Frutas/Yaca.jpg",CV_LOAD_IMAGE_COLOR);
 		resize(Fruta,Fruta2,Size(400,350),0,0,INTER_CUBIC);
 		Fruta2.copyTo(Plantilla(Roi5));
 		putText(Plantilla," Yaca ",Point(0,440),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
		}
		if(Z>15){ 
		Letra.copyTo(Plantilla(roi4)); 
		Nombre.copyTo(Plantilla(roi6));
		cout << " Z "; 
  		putText(Plantilla," Z ",Point(885,640),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
  		Fruta=imread("Frutas/Zarzamora.jpg",CV_LOAD_IMAGE_COLOR);
 		resize(Fruta,Fruta2,Size(400,350),0,0,INTER_CUBIC);
 		Fruta2.copyTo(Plantilla(Roi5));
 		putText(Plantilla," Zarzamora ",Point(0,440),FONT_HERSHEY_PLAIN,3,Scalar(0,0,0),1,CV_AA);
		}
		
		A=B=C=D=E=F=G=H=I=J=K=L=M=N=O=P=Q=R=S=T=U=V=W=X=Y=Z=0;
	        count=0; 
 		
		} 

		//Letra.copyTo(Plantilla(roi4));
		resize(roi,Camara_chica2,Size(200,200),0,0,INTER_CUBIC);
		Camara_chica2.copyTo(Plantilla(roi3));

		
		rectangle(image, Point(rec.x, rec.y),
      		Point(rec.x + rec.width, rec.y + rec.height),Scalar(0, 0, 255), 2);
		
		resize(image,Camara_chica,Size(400,350),0,0,INTER_CUBIC);
       		Camara_chica.copyTo(Plantilla(roi2));	
    		

    		
    		i=contornos.size()+1;

}
}
}
		
		imshow("Sitema",Plantilla);
		if(waitKey(30)>0) break;
		


	}
	
	exit(EXIT_SUCCESS);   


}


void PreProcessImage(Mat *inImage,Mat *outImage,int sizex, int sizey)
{
 Mat grayImage,blurredImage,thresholdImage,contourImage,regionOfInterest;

 vector<vector<Point> > contours;

 cvtColor(*inImage,grayImage , COLOR_BGR2GRAY);

 GaussianBlur(grayImage, blurredImage, Size(5, 5), 2, 2);
 adaptiveThreshold(blurredImage, thresholdImage, 255, 1, 1, 11, 2);

 thresholdImage.copyTo(contourImage);

 findContours(contourImage, contours, RETR_LIST, CHAIN_APPROX_SIMPLE);

 int idx = 0;
 size_t area = 0;
 for (size_t i = 0; i < contours.size(); i++)
 {
  if (area < contours[i].size() )
  {
   idx = i;
   area = contours[i].size();
  }
 }

 Rect rec = boundingRect(contours[idx]);

 regionOfInterest = thresholdImage(rec);

 resize(regionOfInterest,*outImage, Size(sizex, sizey));

}

void LearnFromImages(CvMat* trainData, CvMat* trainClasses)
{
 Mat img;
 char file[255];
 for (int i = 0; i < classes; i++)
 {
  sprintf(file, "%s/%d.png", pathToImages, i);
  img = imread(file, 1);
  if (!img.data)
  {
    cout << "File " << file << " not found\n";
    exit(1);
  }
  Mat outfile;
  PreProcessImage(&img, &outfile, sizex, sizey);
  for (int n = 0; n < ImageSize; n++)
  {
   trainData->data.fl[i * ImageSize + n] = outfile.data[n];
  }
  trainClasses->data.fl[i] = i;
 }
}







