#!/bin/bash
## ==============================================================================================================
## Title:   decompressor
## File:    decompress.sh
## ==============================================================================================================
## Authors: Luis Fernando Alvarez Guerrero,  Antonio Martin Altamirano Cornejo, Daniel Alejandro Vargas Gonzalez
## ==============================================================================================================
## Script que descomprime, compila y acomoda los archivos a modo de Instalador
## ==============================================================================================================
Extraer="search_engine.tar.gz"
Directorio="Documents"
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Main(){
	decompress
	compile
	echo "-I-: Instalacion exitosa"
	exit 0
}
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
decompress(){
  echo " -I-: Descomprimiendo ficheros ...."    
  if [ -d "Fruits" ] ; then 
    echo "                                        "
    echo "-E-: No se puede descomprimir, ya existe el directorio /Fruits/ en la ubicacion actual"
    echo "                                        "
    exit 1
  else
    tar -xv -f "$Extraer" 
    echo "...                                     "
    echo "-I-: Ficheros para base de datos descomprimidos."
    fi
}
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
compile(){
    echo "-I- Compilando search_engine_V3"
#    cd "$Directorio"
    g++ search_engine_V3.cpp -o search_engine -std=c++11 -o search_engine_V3
    echo "-I- Compilado..."
}
#++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
Main 

