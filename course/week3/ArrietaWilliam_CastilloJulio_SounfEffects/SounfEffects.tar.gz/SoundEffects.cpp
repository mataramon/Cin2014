//
// 	Project:		Sockets
// 	File:			/home/wambitz/Workspace/SocketsServer/SoundEffect.cpp
//
//	Created on: 	Jan 9, 2015
//  Authors: 		Julio Alfonso Castillo Cruz & William Emilio Arrieta Lopez
//




