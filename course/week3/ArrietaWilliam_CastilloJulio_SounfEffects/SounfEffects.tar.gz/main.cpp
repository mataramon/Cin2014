/* main.cpp */
#include <iostream>

#include "SoundEffect.h"

using std::cout;
using std::endl;

int main (int argc, char* argv[]) {
	SoundEffect soundhandler;
	if (!soundhandler.engine())
		cout << "Could not startup engine" << endl;
	//cout << "PLAY..." << endl;
	//soundhandler.play("lilium.wav");	// play soound
	//cout << "PLAY ON BACKGROUND..." << endl;
	//soundhandler.playBackground("breve_espacio.mp3", "lilium.wav");
	//cout << "PLAY ECHO..." << endl;
	//soundhandler.playCustomEcho("breve_espacio.mp3");
	cout << "PLAY 3D Sound..." << endl;
	soundhandler.playSurround("breve_espacio.mp3");
	
	
	return 0;
}
