//===============================================//
// Title:       search_engine_V0                 // 
//===============================================//
// Description: a mini search engine c++ based   //
//===============================================//
// Version:     V0                               //
//===============================================//
// Authors:    Alvarez Guerrero Luis Fernando    //
//	       Vargas Gonzalez Daniel Alejandro  //
//             Altamirano Cornejo Antonio Martin //
//-----------------------------------------------//

#include <algorithm>
#include <sys/types.h>
#include <dirent.h>
#include <errno.h>
#include <vector>
#include <string>
#include <fstream>
#include <stdio.h> 
#include <stdlib.h> 
#include <string.h> 
#include <iostream>

using namespace std;

/*
class FilesHandler {
	private:
	
	public:
	
};
*/

/*
class StringProcess {
	private:

	public:
};
*/

// PROTOTYPING
int getdir (string dir, vector<string> &files);

int main(){
// Capturing an argument
	string   tmp_fruit;     // file handler 
	string 	 fruit;         
	char     c;             // string process
	int      lastIndex; 	// string process
	int      counter=0;	// string process
	
//-----------------------------------------------------------------
// opening and listing files in directory for debugging	
	cout << "-D- Listing files in local directory..." << endl;
	cout << endl;
        //saving the list in a file
	ofstream MyFruitList("FruitDataBase.txt");
	//get te direction to take the list of
	string dir = string("./Fruits");	
	//saving the files into a string vector
        vector<string> files = vector<string>();
        getdir(dir,files);
	//file writter iterator
        for (unsigned int i = 0;i < files.size();i++) {
		// removing the extension
		lastIndex = files[i].find_last_of(".");
		tmp_fruit = files[i].substr(0, lastIndex);
		// transform to lower case the current string
		transform(tmp_fruit.begin(),tmp_fruit.end(),tmp_fruit.begin(),::tolower);
		// saving the current filename into the data base file
        	MyFruitList << tmp_fruit << endl;
		/* TODO: Uncoment for debugging.
		displaying the current file name without extension
		cout << fruit << endl;
		*/
        }
	// closing the new file
	MyFruitList.close();  
/////////////////////////////////////////////////////////////////////////////////////////////////

char t_fName[15]; 	                //string process
char Nombre[50];      			//string process
char NewName[15];
char FruitName[128][15];			//string process
char gedit[20] = "gedit Fruits/";	//string process
char txt[20] = ".txt";			//string process
int  i=0;
bool match_flag=false;
int  nLetters=0;                        //string process
int  nMatches=0;
int  fLetters=0;
   
cout << "                      FRUIT FINDER" << "\n";
cout << "                |=======================|" << endl;
cout << "                |";
cin >> Nombre;
	//deleting duplicated and continuous characters
	while (Nombre[nLetters]){
		if (Nombre[nLetters] == Nombre [nLetters+1]){
			//do nothing
		} else {
			NewName[fLetters]=Nombre[nLetters];
			fLetters++;		
		}
		nLetters++;
	}
	
	
	cout << "-D-: corrected word: " << NewName << endl;
	cout << "-D-: quantity of letters : " << fLetters << endl;
	nLetters=0;

	// depuration of typed word
	while (NewName[nLetters]){	
			if (nLetters > 1){
				switch (NewName[nLetters]){
				case 'G' : NewName[nLetters] = '\0';
					break;
				case 'N' : NewName[nLetters] = '\0';
					break;
				case 'U' : NewName[nLetters] = '\0';
					break;
				default: break;
				}
			}nLetters++;		
		}	

	nLetters =0;
	while (NewName[nLetters]){
		c = NewName[nLetters];
		NewName[nLetters] = tolower(c);
		nLetters++;
	}

	cout << "-D-: lower case word : " << NewName << endl;

	//nLetters = 0; // resetting the counter
	// opening the list document
	ifstream fe("FruitDataBase.txt");
	// Reading libe by line
	while(!fe.eof()) {
      		fe >> t_fName;
		// setting as lower case the current string
		//if perfect match was found...
    		if (strcmp (NewName,t_fName) == 0){
			c=t_fName[0];
			t_fName[0] = toupper(c);
			cout << "Search Result:" << endl;
			cout << "     " << t_fName << endl;
			cout << "Opening file..." << endl; 
      			strcat(gedit,t_fName);
     			strcat(gedit,txt);
      			system(gedit);
			match_flag = true;
			counter ++;
   		}
   		else{ 
    			i=1;
      		}
	
  	}
	//if perfect match wasn't found
	counter =0;
   	if(i==1 & !match_flag)
   	{
   		ifstream fe("FruitDataBase.txt");
   		cout << "Closest results: " << "\n";
     		while(!fe.eof()) {
     			fe >> t_fName;
			 // if matches were found....
      			if (strncmp (NewName,t_fName,nLetters) == 0)
     			{
				c=t_fName[0];
				t_fName[0] = toupper(c);
				//copy the current fruit name into a character array
				strcpy(FruitName[counter], t_fName);
      				cout  << FruitName[counter] << "\n";
				nMatches++;
				match_flag = true;
				counter ++;

      			}else{
				i=2;
			}    
       		}
		if (nMatches==1){
			c=FruitName[0][0];
			FruitName[0][0] = toupper(c);
			cout << "only match, opening file " << FruitName[0] << endl;
      			strcat(gedit,FruitName[0]);
     			strcat(gedit,txt);
      			system(gedit);
			match_flag = true;
		}
   	}
	//closing list file
    	fe.close();
	return 0;
}
//---------------------------MAIN END---------------------------------------

int getdir (string dir, vector<string> &files)
{
    DIR *dp;
    struct dirent *dirp;
    if((dp  = opendir(dir.c_str())) == NULL) {
        cout << "Error(" << errno << ") opening " << dir << endl;
        return errno;
    }

    while ((dirp = readdir(dp)) != NULL) {
        files.push_back(string(dirp->d_name));
    }
    closedir(dp);
    return 0;
}


	
