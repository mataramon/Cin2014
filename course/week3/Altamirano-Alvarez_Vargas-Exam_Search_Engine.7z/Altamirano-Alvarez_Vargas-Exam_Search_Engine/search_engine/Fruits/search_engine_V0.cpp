//===============================================//
// Title:       search_engine_V0                 // 
//===============================================//
// Description: a mini search engine c++ based   //
//===============================================//
// Version:     V0                               //
//===============================================//
// Authors:    Alvarez Guerrero Luis Fernando    //
//	       Vargas Gonsalez Daniel Alejandro  //
//             Altamirano Cornejo Antonio Martin //
//-----------------------------------------------//

#include <sys/types.h>
#include <dirent.h>
#include <errno.h>
#include <vector>
#include <fstream>
#include <string>
#include <iostream>
#include <stdio.h>
using namespace std;

class MyArgument{
	private: 
		string argument;
	public:
		MyArgument(string);
		~MyArgument();
		string argum();
		
};

MyArgument::MyArgument(string chars){
	argument = chars;
}

MyArgument::~MyArgument(){
	//destroyer
}

string MyArgument::argum(){
	return argument;
}

int getdir (string dir, vector<string> &files)
{
    DIR *dp;
    struct dirent *dirp;
    if((dp  = opendir(dir.c_str())) == NULL) {
        cout << "Error(" << errno << ") opening " << dir << endl;
        return errno;
    }

    while ((dirp = readdir(dp)) != NULL) {
        files.push_back(string(dirp->d_name));
    }
    closedir(dp);
    return 0;
}

int main(int argc,char *argv[]){
// Capturing an argument
	string fruit;
	int    lastIndex;
	if (argc == 1){  //if there is not an argument written by the user...
		cerr<<"-E-: You should provide letter or a word"<<endl;
		exit(1);
	}
	
	MyArgument MyNewArgument(argv[1]);
	cout << "you tiped: " << MyNewArgument.argum() << endl;
//----------------------------
// opening and listing files in directory for debugging	
	cout << "-D- Listing files in local directory..." << endl;

//saving the list in a file
	ofstream MyFruitList("FruitDataBase.txt");

	string dir = string(".");
        vector<string> files = vector<string>();
        getdir(dir,files);
        for (unsigned int i = 0;i < files.size();i++) {
		if((files[i] == ".") || (files[i] == "..") || (files[i] == "FruitDataBase.txt") || (files[i] == "search_engine_V0.cpp") || (files[i] == "search_engine_V0")){
		}
		else{
		// removing the extension
		lastIndex = files[i].find_last_of(".");
		fruit = files[i].substr(0, lastIndex);
		// saving the current filename into the data base file
        	MyFruitList << fruit << endl;
		// displaying the current file name without extension
		cout << fruit << endl;
		}
        }
	MyFruitList.close();  // closing the new file

	//system("ls -la");
// decomposing the arguments into characters
	string::iterator tmp;
	cout<<"-D- decomposing argument..."<<endl;
	for(tmp =  MyNewArgument.argum().begin(); tmp !=  MyNewArgument.argum().end(); tmp++){
		cout<<(*tmp)<<endl;
	}
	//cout << endl;
	return 0;
}






